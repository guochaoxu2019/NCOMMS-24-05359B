System requriements:
There is no special requriements on system. 
We have used Windows 10 Home edition. 

Installation guide:
Installation could be easily installed through "pip install notebook". Please see "https://jupyter.org/install" for help.

Demo:
Expected result could be found in the souce data of Fig. 3C, which we have provided. 

Instrution for use:
(1) First, install Jupyter Notebook on computer.
(2) Second, start the sklearn process by creating a new workplace.
(3) Download or copy the CSV data file to local documentary, and rementer the pathway.
(4) Using the codes we provided for machine learning. 